package Servlet;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import com.Database.*;

/**
 * Servlet implementation class AddStudent
 */
@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//creating object of print writer
		PrintWriter out = response.getWriter();
		//inserting student data into database
		String Enroll = request.getParameter("enroll_no");
		String Name = request.getParameter("fname");
		String Programme = request.getParameter("programme");
		String Scheme = request.getParameter("scheme");
		String Gender = request.getParameter("gender");
		String Email  = request.getParameter("email");
		String Mobile = request.getParameter("mobile");
		try{
			
			Connection con = Connect.dbconnection();
			Statement st = con.createStatement();
			Statement st1 = con.createStatement();
			String sql = "insert into student(enroll_no,full_name,programme,scheme,gender,email,mobile) values('"+Enroll+"','"+Name+"','"+Programme+"','"+Scheme+"','"+Gender+"','"+Email+"','"+Mobile+"')";
			String query = "insert into student_login(username,password) values('"+Enroll+"','"+Enroll+"')";
			st1.executeUpdate(query);
			st.executeUpdate(sql);
			out.println("<script> alert('Student Added Successfully !!'); </script>");
			RequestDispatcher rd = request.getRequestDispatcher("adminHome.jsp");
		    rd.include(request, response);	
		}
		catch(Exception e)
		{
			RequestDispatcher rd = request.getRequestDispatcher("AdminException.html");
			rd.include(request, response);
		}
	}

}
