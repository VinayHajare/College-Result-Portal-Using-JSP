package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Database.Connect;

/**
 * Servlet implementation class Admin_Login
 */
@WebServlet("/Admin_Login")
public class Admin_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Admin_Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//validating admin 
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		try{
			Connection con = Connect.dbconnection();
			Statement st = con.createStatement();
			String sql = "select * from admin_login where username = '"+username+"' and password = '"+password+"' ";
		    ResultSet rs = st.executeQuery(sql);
		    if(rs.next())
		    {
		    	session.setAttribute("username",username);
		    	out.println("<script> alert('Login Successful !!');</script> ");
		    	RequestDispatcher rd = request.getRequestDispatcher("/adminHome.jsp");
		    	rd.include(request, response);
		    }
		    else
		    {
		    	RequestDispatcher rd = request.getRequestDispatcher("/Erroradminlogin.html");
		    	rd.include(request, response);
		    }
		}
		catch(Exception e)
		{
			RequestDispatcher rd = request.getRequestDispatcher("AdminException.html");
			rd.include(request, response);
		}
	}

}
