package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Database.Connect;

/**
 * Servlet implementation class Change_Pwd
 */
@WebServlet("/Change_Pwd")
public class Change_Pwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Change_Pwd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		String oldpassword = request.getParameter("old_pwd");
		String newpassword = request.getParameter("new_pwd");
		String confirmpassword = request.getParameter("confirm_pwd");
		String username = (String) session.getAttribute("rollno");
		String curr_pwd = (String) session.getAttribute("pass");
		
		if(!(newpassword.equals(confirmpassword)))
		{
			out.println("<script> alert('Passwords do not match. Try again!'); </script>");
	    	RequestDispatcher rd = request.getRequestDispatcher("changePwd.jsp");
		    rd.include(request, response);	
		}
		else if(!curr_pwd.equals(oldpassword))
		{
			System.out.println(curr_pwd);	
			System.out.println(oldpassword);
			out.println("<script> alert('Old Password is incorrect. Try again!'); </script>");
	    	RequestDispatcher rd = request.getRequestDispatcher("changePwd.jsp");
		    rd.include(request, response);				
		}
		else if(oldpassword.equals(newpassword))
		{
			out.println("<script> alert('Old & New password cannot be same. Try again!'); </script>");
	    	RequestDispatcher rd = request.getRequestDispatcher("changePwd.jsp");
		    rd.include(request, response);
		}
		else
		{
			try{	
				Connection con = Connect.dbconnection();
				Statement st = con.createStatement();
				String sql = "update student_login set password='"+newpassword+"' where username='"+username+"'";
				st.executeUpdate(sql);
				out.println("<script> alert('Password Updated Successfully !!'); </script>");
				session.setAttribute("pass", newpassword);
		    	RequestDispatcher rd = request.getRequestDispatcher("studentHome.jsp");
			    rd.include(request, response);	
			}
			catch(Exception e)
			{
				RequestDispatcher rd = request.getRequestDispatcher("StudException.html");
				rd.include(request, response);
			}
		}
	}

}
