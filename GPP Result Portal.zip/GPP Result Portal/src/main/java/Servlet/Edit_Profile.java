package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
import com.Database.*;

/**
 * Servlet implementation class Edit_Profile
 */
@WebServlet("/Edit_Profile")
public class Edit_Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Edit_Profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String Enroll = request.getParameter("enroll_no");
		String Name = request.getParameter("full_name");
		String Programme = request.getParameter("programme");
		String Scheme = request.getParameter("scheme");
		String Gender = request.getParameter("gender");
		String Email  = request.getParameter("email");
		String Mobile = request.getParameter("mobile");
		try{	
			Connection con = Connect.dbconnection();
			Statement st = con.createStatement();
			String sql = "update student set full_name='"+Name+"', programme='"+Programme+"', scheme='"+Scheme+"', gender='"+Gender+"', email='"+Email+"', mobile='"+Mobile+"' where enroll_no='"+Enroll+"'";
			st.executeUpdate(sql);
			out.println("<script> alert('Updated Successfully !!'); </script>");
	    	RequestDispatcher rd = request.getRequestDispatcher("studentHome.jsp");
		    rd.include(request, response);	
		}
		catch(Exception e)
		{
			RequestDispatcher rd = request.getRequestDispatcher("StudException.html");
			rd.include(request, response);
		}
	}

}
