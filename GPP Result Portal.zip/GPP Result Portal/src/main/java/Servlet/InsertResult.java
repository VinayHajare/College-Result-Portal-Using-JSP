package Servlet;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import com.Database.*;

/**
 * Servlet implementation class InsertResult
 */
@WebServlet("/InsertResult")
public class InsertResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertResult() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//creating object of printwriter
		PrintWriter out = response.getWriter();
		
		//inserting student result into database
		String Enroll = request.getParameter("enroll_no");
		String Sem = request.getParameter("sem_no");		
		String Total = request.getParameter("total_marks");
		String s1 = request.getParameter("S1");
		String m1 = request.getParameter("M1");
		String s2 = request.getParameter("S2");
		String m2 = request.getParameter("M2");
		String s3 = request.getParameter("S3");
		String m3 = request.getParameter("M3");
		String s4 = request.getParameter("S4");
		String m4 = request.getParameter("M4");
		String s5 = request.getParameter("S5");
		String m5 = request.getParameter("M5");
		String s6 = request.getParameter("S6");
		String m6 = request.getParameter("M6");
		String s7 = request.getParameter("S7");
		String m7 = request.getParameter("M7");
		String s8 = request.getParameter("S8");
		String m8 = request.getParameter("M8");
		
	    try{
	    	Connection con = Connect.dbconnection();
	    	Statement st = con.createStatement();
	    	String sql = "insert into student_marks(enroll_no,semester_no,total_marks,s1,m1,s2,m2,s3,m3,s4,m4,s5,m5,s6,m6,s7,m7,s8,m8) values('"+Enroll+"','"+Sem+"','"+Total+"','"+s1+"','"+m1+"','"+s2+"','"+m2+"','"+s3+"','"+m3+"','"+s4+"','"+m4+"','"+s5+"','"+m5+"','"+s6+"','"+m6+"','"+s7+"','"+m7+"','"+s8+"','"+m8+"')";
	    	st.executeUpdate(sql);
	    	out.println("<script> alert('Result inserted successfully !!'); </script>");
	    	RequestDispatcher rd = request.getRequestDispatcher("adminHome.jsp");
		    rd.include(request, response);	
	    }
	    catch(Exception e)
	    {
	    	RequestDispatcher rd = request.getRequestDispatcher("AdminException.html");
			rd.include(request, response);
	    }
	}

}
