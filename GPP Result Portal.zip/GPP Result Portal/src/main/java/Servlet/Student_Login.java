package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.Database.Connect;

/**
 * Servlet implementation class Student_Login
 */
@WebServlet("/Student_Login")
public class Student_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Student_Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//validating student login
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		String username = request.getParameter("rollNo");
		String password = request.getParameter("password");
		try{
			Connection con = Connect.dbconnection();
			Statement st = con.createStatement();
			String sql = "select * from student_login where username = '"+username+"' and password = '"+password+"' ";
		    ResultSet rs = st.executeQuery(sql);
		    if(rs.next())
		    {
		    	session.setAttribute("rollno",username);
		    	session.setAttribute("pass",password);
		    	out.println("<script> alert('Login Successfull !!'); </script>");
		    	RequestDispatcher rd = request.getRequestDispatcher("studentHome.jsp");
		    	rd.include(request, response);
		    }
		    else
		    {
		    	RequestDispatcher rd = request.getRequestDispatcher("Errorstudentlogin.html");
		    	rd.include(request, response);
		    }
		}
		catch(Exception e)
		{
			RequestDispatcher rd = request.getRequestDispatcher("StudException.html");
			rd.include(request, response);
		}
	}

}
