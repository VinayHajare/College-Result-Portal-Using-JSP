package com.Database;

import java.sql.*;

public class Connect {
    
	public static Connection dbconnection() throws Exception
	{
		Connection con;
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RMS","root","system");
		return con;
	}
	
	
}
