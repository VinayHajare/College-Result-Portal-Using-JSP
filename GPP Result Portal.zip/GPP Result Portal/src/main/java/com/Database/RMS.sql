--Database Design For GPP Result Management System 
CREATE DATABASE RMS;
--Table for admin login
CREATE TABLE admin_login
(
 username TEXT,
 password TEXT
);
--inserting static entry
insert into admin_login values('admin','admin');
--Table for student login
CREATE TABLE student_login
(
 username TEXT,
 password TEXT
);

--Table for storing student data 
CREATE TABLE student
(
 enroll_no INT(7) PRIMARY KEY,
 full_name TEXT,
 programme TEXT,
 scheme TEXT,
 gender TEXT,
 email TEXT,
 mobile TEXT
);
-- Table for storing student marks
CREATE TABLE student_marks
(
 enroll_no TEXT,
 semester_no TEXT,
 total_marks TEXT,
 s1 TEXT,
 m1 TEXT,
 s2 TEXT,
 m2 TEXT,
 s3 TEXT,
 m3 TEXT,
 s4 TEXT,
 m4 TEXT,
 s5 TEXT,
 m5 TEXT,
 s6 TEXT,
 m6 TEXT,
 s7 TEXT,
 m7 TEXT,
 s8 TEXT,
 m8 TEXT,
);